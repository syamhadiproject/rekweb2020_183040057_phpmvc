<?php

class User_model {
	private $nama = 'M Syamsul Hadi Rahman';

	public function getUser() 
	{
	
		return $this->nama;
	
	}
}